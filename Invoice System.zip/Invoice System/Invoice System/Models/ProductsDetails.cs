﻿namespace Invoice_System.Models
{
    public class ProductsDetails
    {
        public List<Products> Products { get; set; }
    }
}
