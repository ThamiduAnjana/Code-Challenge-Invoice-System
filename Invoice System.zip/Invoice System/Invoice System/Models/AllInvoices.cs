﻿namespace Invoice_System.Models
{
    public class AllInvoices
    {
        public List<Invoice> Invoices { get; set; }
    }
}
