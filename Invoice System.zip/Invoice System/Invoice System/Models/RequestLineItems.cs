﻿namespace Invoice_System.Models
{
    public class RequestLineItems
    {
        public string Code { get; set; }
        public int Qty { get; set; }
    }
}
